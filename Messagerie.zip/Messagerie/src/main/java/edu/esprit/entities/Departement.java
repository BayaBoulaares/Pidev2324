package edu.esprit.entities;

import java.util.Date;

public class Departement {
    private int id;
    private String nom;
    private Date date;

    // Constructors, getters, and setters can be added here
}
