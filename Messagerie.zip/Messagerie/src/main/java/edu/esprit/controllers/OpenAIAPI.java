package edu.esprit.controllers;

public interface OpenAIAPI {
}
