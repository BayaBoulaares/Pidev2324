package edu.esprit.controllers;

public class SupprimerMessage {
}
